# MERN Stack App with MySQL

A full-stack web application with user authentication and CRUD dashboard.

**Tech Stack:** React.js + Tailwind CSS + Express.js + MySQL + JWT

---

## MySQL Database Setup

1. Install MySQL or use XAMPP/WAMP
2. Open MySQL Workbench or phpMyAdmin
3. Run the file: `backend/database.sql`
4. This creates the `mern_auth_db` database with `users` and `items` tables

---

## Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file (copy from `.env.example`):
```
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=mern_auth_db
JWT_SECRET=your_super_secret_key
JWT_EXPIRE=7d
```

Start the server:
```bash
npm run dev
```
Server runs at: http://localhost:5000

---

## Frontend Setup

```bash
cd frontend
npm install
npm run dev
```
Frontend runs at: http://localhost:5173

---

## API Endpoints

### Auth Routes
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login user |
| GET | /api/auth/me | Get current user (Protected) |
| POST | /api/auth/forgot-password | Generate reset token |
| POST | /api/auth/reset-password | Reset password with token |

### Item Routes (All Protected)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/items | Get all items |
| GET | /api/items/:id | Get single item |
| POST | /api/items | Create new item |
| PUT | /api/items/:id | Update item |
| DELETE | /api/items/:id | Delete item |
| GET | /api/items/stats | Get dashboard statistics |

---

## Features
- User registration and login with JWT authentication
- Password hashing with bcryptjs
- Forgot/reset password flow
- Full CRUD operations for items
- Dashboard with statistics (total, active, pending, completed)
- Protected routes (frontend + backend)
- Responsive design with Tailwind CSS
- SQL injection prevention with parameterized queries
- Error handling middleware
- CORS middleware
