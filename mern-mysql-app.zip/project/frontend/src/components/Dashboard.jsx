import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getItems, createItem, updateItem, deleteItem, getStats } from '../api/itemApi';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { user, logoutUser } = useAuth();
  const navigate = useNavigate();

  const [items, setItems] = useState([]);
  const [stats, setStats] = useState({ total: 0, active: 0, pending: 0, completed: 0 });
  const [form, setForm] = useState({ title: '', description: '', status: 'active' });
  const [editId, setEditId] = useState(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const fetchData = async () => {
    try {
      const [itemsRes, statsRes] = await Promise.all([getItems(), getStats()]);
      setItems(itemsRes.data.items);
      setStats(statsRes.data.stats);
    } catch (err) {
      console.error(err);
    } finally {
      setFetching(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const showSuccess = (msg) => {
    setSuccess(msg);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    if (!form.title.trim()) return setError('Title is required.');
    setLoading(true);
    setError('');
    try {
      if (editId) {
        await updateItem(editId, form);
        showSuccess('Item updated successfully!');
        setEditId(null);
      } else {
        await createItem(form);
        showSuccess('Item added successfully!');
      }
      setForm({ title: '', description: '', status: 'active' });
      fetchData();
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item) => {
    setEditId(item.id);
    setForm({ title: item.title, description: item.description || '', status: item.status });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async () => {
    try {
      await deleteItem(deleteConfirmId);
      setDeleteConfirmId(null);
      showSuccess('Item deleted.');
      fetchData();
    } catch (err) {
      setError('Failed to delete item.');
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    const item = items.find(i => i.id === id);
    try {
      await updateItem(id, { ...item, status: newStatus });
      fetchData();
    } catch (err) { console.error(err); }
  };

  const handleLogout = () => {
    logoutUser();
    navigate('/login');
  };

  const statCards = [
    { label: 'Total Items', value: stats.total, color: 'bg-blue-100 text-blue-700', border: 'border-blue-200' },
    { label: 'Active', value: stats.active, color: 'bg-green-100 text-green-700', border: 'border-green-200' },
    { label: 'Pending', value: stats.pending, color: 'bg-yellow-100 text-yellow-700', border: 'border-yellow-200' },
    { label: 'Completed', value: stats.completed, color: 'bg-gray-100 text-gray-700', border: 'border-gray-200' },
  ];

  const statusBadge = (status) => {
    const map = {
      active: 'bg-green-100 text-green-700',
      pending: 'bg-yellow-100 text-yellow-700',
      completed: 'bg-gray-100 text-gray-600',
    };
    return map[status] || 'bg-gray-100 text-gray-600';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-blue-600 text-white px-6 py-4 flex justify-between items-center shadow">
        <h1 className="text-xl font-bold">📋 My Dashboard</h1>
        <div className="flex items-center gap-4">
          <span className="text-sm hidden sm:block">👋 Hello, <strong>{user?.name}</strong></span>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-600 text-sm font-semibold px-4 py-2 rounded-lg hover:bg-blue-50 transition"
          >
            Logout
          </button>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {statCards.map(({ label, value, color, border }) => (
            <div key={label} className={`${color} border ${border} rounded-xl p-4 text-center`}>
              <div className="text-3xl font-bold">{value || 0}</div>
              <div className="text-sm mt-1 font-medium">{label}</div>
            </div>
          ))}
        </div>

        {/* Add / Edit Form */}
        <div className="bg-white rounded-2xl shadow p-6 mb-8">
          <h2 className="text-lg font-semibold mb-4 text-gray-800">
            {editId ? '✏️ Edit Item' : '➕ Add New Item'}
          </h2>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">{error}</div>
          )}
          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{success}</div>
          )}

          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
            <input
              name="title" value={form.title} onChange={handleChange}
              placeholder="Enter item title"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              name="description" value={form.description} onChange={handleChange}
              placeholder="Enter description (optional)" rows="3"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select
              name="status" value={form.status} onChange={handleChange}
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleSubmit} disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2.5 rounded-lg transition disabled:opacity-50"
            >
              {loading ? 'Saving...' : editId ? 'Update Item' : 'Add Item'}
            </button>
            {editId && (
              <button
                onClick={() => { setEditId(null); setForm({ title: '', description: '', status: 'active' }); setError(''); }}
                className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold px-6 py-2.5 rounded-lg transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        {/* Items Table */}
        <div className="bg-white rounded-2xl shadow">
          <div className="p-6 border-b">
            <h2 className="text-lg font-semibold text-gray-800">📦 Your Items</h2>
          </div>

          {fetching ? (
            <div className="p-8 text-center text-gray-400">Loading items...</div>
          ) : items.length === 0 ? (
            <div className="p-8 text-center text-gray-400">
              <p className="text-4xl mb-3">📭</p>
              <p>No items yet. Add your first item above!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 text-xs text-gray-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-3 text-left">Title</th>
                    <th className="px-6 py-3 text-left hidden sm:table-cell">Description</th>
                    <th className="px-6 py-3 text-left">Status</th>
                    <th className="px-6 py-3 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {items.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-4 font-medium text-gray-800">{item.title}</td>
                      <td className="px-6 py-4 text-gray-500 text-sm hidden sm:table-cell">
                        {item.description ? item.description.slice(0, 60) + (item.description.length > 60 ? '...' : '') : '—'}
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={item.status}
                          onChange={(e) => handleStatusChange(item.id, e.target.value)}
                          className={`text-xs font-semibold px-2 py-1 rounded-full border-0 cursor-pointer ${statusBadge(item.status)}`}
                        >
                          <option value="active">Active</option>
                          <option value="pending">Pending</option>
                          <option value="completed">Completed</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleEdit(item)}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium mr-4"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(item.id)}
                          className="text-red-500 hover:text-red-700 text-sm font-medium"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Delete Item?</h3>
            <p className="text-gray-500 text-sm mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button
                onClick={handleDelete}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2.5 rounded-lg transition"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-2.5 rounded-lg transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
